<?php
session_start();
require_once '../web_db/multi_values.php';
?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Loan requested report</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <div class="parts no_paddin_shade_no_Border xx_titles">
                Loan Requested Report
            </div>
            <?php
            $obj = new multi_values();
            $first = $obj->get_first_loan();
            $obj->list_loan1_manger($first);
            ?>
        </div>
    </body>
</html>
