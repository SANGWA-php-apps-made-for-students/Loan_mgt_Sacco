<?php
session_start();
require_once '../web_db/updates.php';
require_once '../web_db/multi_values.php';
?>
<html>
    <head>
        <title>Sacco</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include 'admin_header.php';
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <div class="parts full_center_two_h heit_free search_bg">

                <span class="table_center">    
                    <fieldset align center><legend align center><i><b>Change password</b></i></legend>

                        <form method="post" action="change_pass.php" >
                            <table bgcolor="pink" width="50%" border="0" align="center" style="border: 1px solid #00000;">
                                <tr>
                                </tr>
                                <tr align="center">
                                    <td colspan="2"><font size='3'><b>
                                            <I>change password form</I></b></font></td>
                                </tr>
                                <tr>
                                    <td><font size='3' color='#000000'>Username</font></td>
                                    <td>
                                        <?php get_username_combo();?>
                                    </td></tr>

                                <tr>
                                    <td><font size='3' color='#000000'>Old Password</font></td>
                                    <td><input name="password" type="password"  required/></td></tr>
                                <tr>
                                    <td><font size='3' color='#000000'>NewPassword</font></td>
                                    <td><input name="new_password" type="password"  required/></td></tr>
                                <td colspan="2">
                                </td></tr>
                                <tr align="center">
                                    <td colspan="3"><input name="validate_users" type="submit" value="Password changed" /></td>
                                </tr> 
                            </table>
                        </form>

                    </fieldset>
                </span>
            </div>
            <div class="parts eighty_centered footer"> GATENGA SACCO <?php echo date("Y") ?></div>
            <?php
//            $obj = new multi_values();
//            $first = $obj->get_first_transaction();
//            $obj->get_balance();
            ?>
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>

<?php
function get_username_combo(){
    $obj= new multi_values();
    $obj->get_usernames_in_combo();
}
if (isset($_POST['validate_users'])) {
    require_once '../web_db/multi_values.php';

    $username = trim($_POST['username']);
    $n_password = $_POST['new_password'];
    $getter = new multi_values();
    $upd = new updates();
    $getter->get_username_check($username); //if the username exists
    if (!empty($getter)) {//if username exists
        $upd->update_account_username($n_password, $username);
        ?><script>alert('Account save successfully!');</script><?php
    } else {
        ?><script>alert('The username desnt exists');</script><?php
    }
}