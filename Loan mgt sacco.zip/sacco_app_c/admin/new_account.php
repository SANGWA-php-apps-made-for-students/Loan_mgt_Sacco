<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_account'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $account_id = $_SESSION['id_upd'];
            $account_category = trim($_POST['txt_account_category_id']);
            $date_created = date('y-m-d');
            $profile = $_POST['txt_profile_id'];
            $username = $_POST['txt_username'];
            $password = $_POST['txt_password'];
            $is_online = 'no';
            $upd_obj->update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $dob = $_POST['txt_dob'];
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $gender = $_POST['txt_gender'];
        $telephone_number = $_POST['txt_telephone_number'];
        $email = $_POST['txt_email'];
        $residence = $_POST['txt_residence'];
        $image = 1;
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image);
        $mul = new multi_values();
        $last_profile = $mul->get_last_profile();
        $account_category = trim($_POST['txt_account_category_id']);
        $date_created = date('y-m-d');
        $username = $_POST['txt_username'];
        $password = $_POST['txt_password'];
        if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬]/', $password)) {
            // one or more of the 'special characters' found in $string
            if (preg_match('/[A-Z]/', $password)) {
                // There is one upper
                if (preg_match('/[0-9]/', $password)) {
                    $is_online = 'no';
                    $obj = new new_values();
                    $obj->new_account($account_category, $date_created, $last_profile, $username, $password, $is_online);
                } else {
                    ?><script>alert('The password must  contain Upper case and a character  ');</script><?php
                }
            } else {
                ?><script>alert('The password must  contain Upper case and a character  ');</script><?php
            }
        } else {
            ?><script>alert('The password must  contain Upper case and a character  ');</script><?php
        }
    }
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
            account</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_account_category_id"   name="txt_account_category_id"/><input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                account saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered no_shade_noBorder big_t">  Account Registration</div>

                <div class="parts fifty_percent_two_h heit_free no_shade_noBorder"> 
                    <table>
                        <tr><td>account_category :</td><td> <?php
                                if ($_SESSION['cat'] == 'manager') {
                                    get_manager_acc_cat_combo();
                                } else {
                                    get_account_category_combo();
                                }
                                ?>  </td></tr>
                        <tr><td>Date Of birth :</td><td> <input type="text" id="date_pick"     name="txt_dob" autocomplete="off" required class="textbox " value="<?php echo trim(chosen_dob_upd()); ?>"   />  </td></tr>
                        <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                        <tr><td>last_name :</td><td> <input type="text"     name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                        <tr><td>telephone_number :</td><td> <input type="text"     name="txt_telephone_number" required class="textbox only_numbers" value="<?php echo trim(chosen_telephone_number_upd()); ?>"   />  </td></tr>
                    </table></div>
                <div class="parts fifty_percent_two_h heit_free no_shade_noBorder">
                    <table>
                        <tr><td>gender :</td><td>
                                <select  name="txt_gender" required class="textbox">
                                    <option>  </option>
                                    <option> Male </option>
                                    <option> 
                                        Female </option>
                                </select>
                        </tr> 
                        <tr><td>email :</td><td> <input type="email"     name="txt_email" required class="textbox email" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                        <tr><td>residence :</td><td> <input type="text"     name="txt_residence" required class="textbox" value="<?php echo trim(chosen_residence_upd()); ?>"   />  </td></tr>
                        <tr><td>Username :</td><td> <input type="text"     name="txt_username" required class="textbox Only_emails" value="<?php echo trim(chosen_password_upd()); ?>"   />  </td></tr>
                        <tr><td>password :</td><td> <input type="password"     name="txt_password" required class="textbox" value="<?php echo trim(chosen_password_upd()); ?>"   />  </td></tr>
                        <tr><td colspan="2"> <input type="submit"  class="confirm_buttons" name="send_account" value="Save"/>  </td></tr>
                    </table></div>
            </div>
            <div class="parts eighty_centered datalist_box " >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">account List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_account();
                $obj->list_account($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script>
                 $(document).ready(function () {
                     $('#date_pick').datepicker({
                         dateFormat: 'yy-mm-dd'
                     });
                 });
        </script>
        <div class="parts eighty_centered footer"> <p style="color:blue; font-size:14px; ">GATENGA SACCO <?php echo date("y-m-d"); ?></p></div>
    </body>
</hmtl>
<?php

function get_account_category_combo() {
    $obj = new multi_values();
    $obj->get_account_category_in_combo();
}

function get_manager_acc_cat_combo() {
    $obj = new multi_values();
    $obj->get_manger_acc_cat_in_combo();
}

function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function chosen_account_category_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $account_category = new multi_values();
            return $account_category->get_chosen_account_account_category($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_created_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $date_created = new multi_values();
            return $date_created->get_chosen_account_date_created($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $profile = new multi_values();
            return $profile->get_chosen_account_profile($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_username_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $username = new multi_values();
            return $username->get_chosen_account_username($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_password_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $password = new multi_values();
            return $password->get_chosen_account_password($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_is_online_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $is_online = new multi_values();
            return $is_online->get_chosen_account_is_online($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// <editor-fold defaultstate="collapsed" desc="--- this is profile -----">

function get_image_combo() {
    $obj = new multi_values();
    $obj->get_image_in_combo();
}

function chosen_dob_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $dob = new multi_values();
            return $dob->get_chosen_profile_dob($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_profile_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_last_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $last_name = new multi_values();
            return $last_name->get_chosen_profile_last_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_gender_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $gender = new multi_values();
            return $gender->get_chosen_profile_gender($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_telephone_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $telephone_number = new multi_values();
            return $telephone_number->get_chosen_profile_telephone_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_email_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $email = new multi_values();
            return $email->get_chosen_profile_email($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_residence_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $residence = new multi_values();
            return $residence->get_chosen_profile_residence($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_image_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $image = new multi_values();
            return $image->get_chosen_profile_image($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// </editor-fold>



    