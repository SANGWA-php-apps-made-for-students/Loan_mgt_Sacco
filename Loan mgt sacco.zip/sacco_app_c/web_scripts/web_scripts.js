var n = 0;
var c = 1;
var n1 = 0;
$(document).ready(function () {
    try {
        get_new_data_hide_show();
        show_form_toUpdate();
        customer_del_udpate();
//    get_pages_moving();
        dlog_btn_No_Yes();
        hide_select_pane();

        get_account_category_id_combo();
        get_profile_id_combo();
        get_image_id_combo();
        get_account_id_combo();
        get_customer_id_combo();
        get_loan_id_combo();
        get_trans_type_id_combo();
        get_bank_acc_id_combo();
        get_account_id_combo();
        //   get_username_id_combo();
        account_category_del_udpate();

        account_del_udpate();
        image_del_udpate();
        account_del_udpate();
        customer_del_udpate();

        trans_type_del_udpate();
        customer_del_udpate();
        loan_del_udpate();
        loan_payment_del_udpate();
        validate_numbers_textfields();
        bk_acc_del_udpate();
        transaction_del_udpate();
        approve_loan();
        anim();
        search_cust_det();
    } catch (err) {
        alert(err.message);
    }
});

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
            $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
            $('#txt_profile_id').val(cbo_profile);

        });
    } catch (err) {
        alert(err.message);
    }
}
function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
            $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
            $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_customer_id_combo() {
    try {
        $('.cbo_customer').change(function () {
            var cbo_customer = $('.cbo_customer option:selected').val();
            $('#txt_customer_id').val(cbo_customer);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_loan_id_combo() {
    try {
        $('.cbo_loan').change(function () {
            var cbo_loan = $('.cbo_loan option:selected').val();
            $('#txt_loan_id').val(cbo_loan);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_customer_id_combo() {
    try {
        $('.cbo_customer').change(function () {
            var cbo_customer = $('.cbo_customer option:selected').val();
            $('#txt_customer_id').val(cbo_customer);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_trans_type_id_combo() {
    try {
        $('.cbo_trans_type').change(function () {
            var cbo_trans_type = $('.cbo_trans_type option:selected').val();
            $('#txt_trans_type_id').val(cbo_trans_type);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_bank_acc_id_combo() {
    try {
        $('.cbo_bank_acc').change(function () {
            var cbo_bank_acc = $('.cbo_bank_acc option:selected').val();
            $('#txt_bank_acc_id').val(cbo_bank_acc);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
            $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_new_data_hide_show() {
    $('.new_data_hider').click(function () {
        $('.new_data_box').slideToggle();
    });

}
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
            //here its fine!.
        } else {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname = $('#txt_shall_expand_toUpdate').val();
    if (updname != '') {
        $('.new_data_box').delay(200).slideDown();
    }

}
function postDisplayData(call_dialog, div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}
function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
        alert('Declined!');
    });
}
function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}

//update from account ...

function account_del_udpate() {
    $('.account_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
    $('.account_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from account_category ...

function account_category_del_udpate() {
    $('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
    $('.account_category_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account_category').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from profile ...

function profile_del_udpate() {
    $('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
    $('.profile_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.profile').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from image ...

function image_del_udpate() {
    $('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
    $('.image_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.image').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from contact_us ...

function contact_us_del_udpate() {
    $('.contact_us_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcontact_us.. 
    $('.contact_us_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from trans_type ...

function trans_type_del_udpate() {
    $('.trans_type_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.trans_type').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromtrans_type.. 
    $('.trans_type_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.trans_type').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from bk_acc ...

function bk_acc_del_udpate() {
    $('.bk_acc_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.bk_acc').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombk_acc.. 
    $('.bk_acc_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.bk_acc').attr('title');
        var id_delete = $(this).attr('value').trim();
        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });
    });
}//update from loan_payment ...

function loan_payment_del_udpate() {
    $('.loan_payment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.loan_payment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromloan_payment.. 
    $('.loan_payment_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.loan_payment').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from loan ...

function loan_del_udpate() {
    $('.loan_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.loan').attr('title');
        var id_update = $(this).attr('value').trim();
        alert(id_update);
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromloan.. 
    $('.loan_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.loan').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from transaction ...

function transaction_del_udpate() {
    $('.transaction_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.transaction').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromtransaction.. 
    $('.transaction_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.transaction').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from customer ...

function customer_del_udpate() {
    $('.customer_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.customer').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcustomer.. 
    $('.customer_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.customer').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}

function approve_loan() {
    $('.loan_approve_link').unbind('click').click(function () {
//        var approve_loan = $(this).attr('value');
        var approve_loan = $(this).closest('td').siblings('.loanid_col').html().trim();

        $.post('../Admin/handler.php', {approve_loan: approve_loan}, function (data) {
//            alert('reached: ' + data);
        }).complete(function () {
            window.location.reload();
        });
    });
    search_balance();
    check_loan();
}
function search_balance() {
    $('.btn_search_balance').unbind('click').click(function () {
        $('.res_box').html('');
        $('.res_box').addClass('loading_bg');
        countdown(n);
    });
}
function search_cust_det() {
    try {
        $('.btn_search_NID').unbind('click').click(function () {
            var acc_search_cust = $('#txt_natioanlId').val();
           
        $.post('../admin/handler.php', {acc_search_cust: acc_search_cust}, function (data) {
            $('.res_box').delay(15000, function () {
                $('.res_box').html(data);
            });
        }).complete(function () {
            $('.res_box').removeClass('loading_bg');
            $('.datalist_box').slideUp(2000);
        });
        });
    } catch (err) {
        alert(err.message);
    }




//    $('.btn_search_NID').unbind('click').click(function () {
//      
//        $('.res_box').html('');
//        $('.res_box').addClass('loading_bg');
//        countdown_cust(n1);
//    });
}
function check_loan() {
    $('.btn_search_loan').click(function () {
        $('.res_box').html('');
        $('.res_box').addClass('loading_bg');

        countdown_loans(n);
    });
}
function countdown(n) {
    setTimeout(function () {
        n += 1;
        if (n === 3) {
            var acc_search = $('.search_tbox').val();
            post_data(acc_search);
        }
        countdown(n);
    }, 1000);
}
function countdown_cust(n) {
    setTimeout(function () {
        n += 1;
        if (n === 3) {
            var acc_search_cust = $('.txt_natioanlId').val();
            post_data_cust(acc_search_cust);
        }
        countdown_cust(n);
    }, 1000);
}
function countdown_loans(n) {
    setTimeout(function () {
        n += 1;
        if (n === 3) {
            var acc_search = $('.txt_search_loans').val();
            post_data_loans(acc_search);
        }
        countdown_loans(n);
    }, 1000);
}
function post_data(acc_search) {
    $.post('../Admin/handler.php', {acc_search: acc_search}, function (data) {
        $('.res_box').delay(15000, function () {
            $('.res_box').html(data);
        });
    }).complete(function () {
        $('.res_box').removeClass('loading_bg');
    });
}
function post_data_loans(acc_search_loan) {
    $.post('../Admin/handler.php', {acc_search_loan: acc_search_loan}, function (data) {
        $('.res_box').delay(15000, function () {
            $('.res_box').html(data);
        });
    }).complete(function () {
        $('.res_box').removeClass('loading_bg');
    });
}
function post_data_cust(acc_search_cust) {

}
function anim() {
    $('.menu').delay(700).slideDown();
    setTimeout(function () {
        if (c == 3) {
//      $('#bg_top').addClass('bigger_title').html('Best Service for you');
            c = 0;
        }

        $('.slider').hide();
        $('#slide_' + c).fadeIn(300);
        c += 1;
        anim();
    }, 2000);
}