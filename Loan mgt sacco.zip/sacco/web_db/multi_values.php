<?php
 require_once '../web_db/connection.php'; 
class multi_values{


function list_account($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account </td>
<td> account_category </td><td> date_created </td><td> profile </td><td> username </td><td> password </td><td> is_online </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td class="account_category_id_cols account " title="account" >
<?php echo  $this->_e($row['account_category']); ?>
</td>
<td>
<?php echo  $this->_e($row['date_created']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['username']); ?>
</td>
<td>
<?php echo  $this->_e($row['password']); ?>
</td>
<td>
<?php echo  $this->_e($row['is_online']); ?>
</td>


<td>
                        <a href="#" class="account_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_account_category($id) {
        
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    } function get_chosen_account_date_created($id) {
        
        $db = new dbconnection();
        $sql = "select   account.date_created from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_created'];
        echo $field;
    } function get_chosen_account_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_account_username($id) {
        
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    } function get_chosen_account_password($id) {
        
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    } function get_chosen_account_is_online($id) {
        
        $db = new dbconnection();
        $sql = "select   account.is_online from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['is_online'];
        echo $field;
    }

 function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
 function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
function list_account_category($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account_category";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account_category </td>
<td> name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_category_id']; ?>
</td>
<td class="name_id_cols account_category " title="account_category" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_category_name($id) {
        
        $db = new dbconnection();
        $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_account_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_category_id   from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
 function get_last_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
function list_profile($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from profile";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> profile </td>
<td> dob </td><td> name </td><td> last_name </td><td> gender </td><td> telephone_number </td><td> email </td><td> residence </td><td> image </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['profile_id']; ?>
</td>
<td class="dob_id_cols profile " title="profile" >
<?php echo  $this->_e($row['dob']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>
<td>
<?php echo  $this->_e($row['last_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['gender']); ?>
</td>
<td>
<?php echo  $this->_e($row['telephone_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['email']); ?>
</td>
<td>
<?php echo  $this->_e($row['residence']); ?>
</td>
<td>
<?php echo  $this->_e($row['image']); ?>
</td>


<td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_profile_dob($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    } function get_chosen_profile_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    } function get_chosen_profile_last_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    } function get_chosen_profile_gender($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    } function get_chosen_profile_telephone_number($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['telephone_number'];
        echo $field;
    } function get_chosen_profile_email($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    } function get_chosen_profile_residence($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    } function get_chosen_profile_image($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

 function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
 function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
function list_image($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from image";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> image </td>
<td> path </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['image_id']; ?>
</td>
<td class="path_id_cols image " title="image" >
<?php echo  $this->_e($row['path']); ?>
</td>


<td>
                        <a href="#" class="image_delete_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_image_path($id) {
        
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['path'];
        echo $field;
    }

 function All_image() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  image_id   from image";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
 function get_last_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
function list_contact_us($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from contact_us";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> contact_us </td>
<td> account </td><td> date_contact </td><td> message </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['contact_us_id']; ?>
</td>
<td class="account_id_cols contact_us " title="contact_us" >
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['date_contact']); ?>
</td>
<td>
<?php echo  $this->_e($row['message']); ?>
</td>


<td>
                        <a href="#" class="contact_us_delete_link" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="contact_us_update_link" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_contact_us_account($id) {
        
        $db = new dbconnection();
        $sql = "select   contact_us.account from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_contact_us_date_contact($id) {
        
        $db = new dbconnection();
        $sql = "select   contact_us.date_contact from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_contact'];
        echo $field;
    } function get_chosen_contact_us_message($id) {
        
        $db = new dbconnection();
        $sql = "select   contact_us.message from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['message'];
        echo $field;
    }

 function All_contact_us() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  contact_us_id   from contact_us";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_contact_us() {
        $con = new dbconnection();
        $sql = "select contact_us.contact_us_id from contact_us
                    order by contact_us.contact_us_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['contact_us_id'];
        return $first_rec;
    }
 function get_last_contact_us() {
        $con = new dbconnection();
        $sql = "select contact_us.contact_us_id from contact_us
                    order by contact_us.contact_us_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['contact_us_id'];
        return $first_rec;
    }
function list_trans_type($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from trans_type";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> trans_type </td>
<td> name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['trans_type_id']; ?>
</td>
<td class="name_id_cols trans_type " title="trans_type" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="trans_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['trans_type_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="trans_type_update_link" style="color: #000080;" value="
                           <?php echo $row['trans_type_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_trans_type_name($id) {
        
        $db = new dbconnection();
        $sql = "select   trans_type.name from trans_type where trans_type_id=:trans_type_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':trans_type_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_trans_type() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  trans_type_id   from trans_type";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_trans_type() {
        $con = new dbconnection();
        $sql = "select trans_type.trans_type_id from trans_type
                    order by trans_type.trans_type_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['trans_type_id'];
        return $first_rec;
    }
 function get_last_trans_type() {
        $con = new dbconnection();
        $sql = "select trans_type.trans_type_id from trans_type
                    order by trans_type.trans_type_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['trans_type_id'];
        return $first_rec;
    }
function list_bk_acc($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from bk_acc";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> bk_acc </td>
<td> acc_number </td><td> date </td><td> acc_type </td><td> customer </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['bk_acc_id']; ?>
</td>
<td class="acc_number_id_cols bk_acc " title="bk_acc" >
<?php echo  $this->_e($row['acc_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['acc_type']); ?>
</td>
<td>
<?php echo  $this->_e($row['customer']); ?>
</td>


<td>
                        <a href="#" class="bk_acc_delete_link" style="color: #000080;" value="
                           <?php echo $row['bk_acc_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="bk_acc_update_link" style="color: #000080;" value="
                           <?php echo $row['bk_acc_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_bk_acc_acc_number($id) {
        
        $db = new dbconnection();
        $sql = "select   bk_acc.acc_number from bk_acc where bk_acc_id=:bk_acc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':bk_acc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['acc_number'];
        echo $field;
    } function get_chosen_bk_acc_date($id) {
        
        $db = new dbconnection();
        $sql = "select   bk_acc.date from bk_acc where bk_acc_id=:bk_acc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':bk_acc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_bk_acc_acc_type($id) {
        
        $db = new dbconnection();
        $sql = "select   bk_acc.acc_type from bk_acc where bk_acc_id=:bk_acc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':bk_acc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['acc_type'];
        echo $field;
    } function get_chosen_bk_acc_customer($id) {
        
        $db = new dbconnection();
        $sql = "select   bk_acc.customer from bk_acc where bk_acc_id=:bk_acc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':bk_acc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['customer'];
        echo $field;
    }

 function All_bk_acc() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  bk_acc_id   from bk_acc";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_bk_acc() {
        $con = new dbconnection();
        $sql = "select bk_acc.bk_acc_id from bk_acc
                    order by bk_acc.bk_acc_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['bk_acc_id'];
        return $first_rec;
    }
 function get_last_bk_acc() {
        $con = new dbconnection();
        $sql = "select bk_acc.bk_acc_id from bk_acc
                    order by bk_acc.bk_acc_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['bk_acc_id'];
        return $first_rec;
    }
function list_loan_payment($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from loan_payment";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> loan_payment </td>
<td> loan </td><td> date </td><td> amount_paid </td><td> remaining </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['loan_payment_id']; ?>
</td>
<td class="loan_id_cols loan_payment " title="loan_payment" >
<?php echo  $this->_e($row['loan']); ?>
</td>
<td>
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['amount_paid']); ?>
</td>
<td>
<?php echo  $this->_e($row['remaining']); ?>
</td>


<td>
                        <a href="#" class="loan_payment_delete_link" style="color: #000080;" value="
                           <?php echo $row['loan_payment_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="loan_payment_update_link" style="color: #000080;" value="
                           <?php echo $row['loan_payment_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_loan_payment_loan($id) {
        
        $db = new dbconnection();
        $sql = "select   loan_payment.loan from loan_payment where loan_payment_id=:loan_payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['loan'];
        echo $field;
    } function get_chosen_loan_payment_date($id) {
        
        $db = new dbconnection();
        $sql = "select   loan_payment.date from loan_payment where loan_payment_id=:loan_payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_loan_payment_amount_paid($id) {
        
        $db = new dbconnection();
        $sql = "select   loan_payment.amount_paid from loan_payment where loan_payment_id=:loan_payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['amount_paid'];
        echo $field;
    } function get_chosen_loan_payment_remaining($id) {
        
        $db = new dbconnection();
        $sql = "select   loan_payment.remaining from loan_payment where loan_payment_id=:loan_payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['remaining'];
        echo $field;
    }

 function All_loan_payment() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  loan_payment_id   from loan_payment";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_loan_payment() {
        $con = new dbconnection();
        $sql = "select loan_payment.loan_payment_id from loan_payment
                    order by loan_payment.loan_payment_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['loan_payment_id'];
        return $first_rec;
    }
 function get_last_loan_payment() {
        $con = new dbconnection();
        $sql = "select loan_payment.loan_payment_id from loan_payment
                    order by loan_payment.loan_payment_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['loan_payment_id'];
        return $first_rec;
    }
function list_loan($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from loan";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> loan </td>
<td> date </td><td> amount_borrowed </td><td> rate </td><td> amount_due </td><td> status </td><td> customer </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['loan_id']; ?>
</td>
<td class="date_id_cols loan " title="loan" >
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['amount_borrowed']); ?>
</td>
<td>
<?php echo  $this->_e($row['rate']); ?>
</td>
<td>
<?php echo  $this->_e($row['amount_due']); ?>
</td>
<td>
<?php echo  $this->_e($row['status']); ?>
</td>
<td>
<?php echo  $this->_e($row['customer']); ?>
</td>


<td>
                        <a href="#" class="loan_delete_link" style="color: #000080;" value="
                           <?php echo $row['loan_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="loan_update_link" style="color: #000080;" value="
                           <?php echo $row['loan_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_loan_date($id) {
        
        $db = new dbconnection();
        $sql = "select   loan.date from loan where loan_id=:loan_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_loan_amount_borrowed($id) {
        
        $db = new dbconnection();
        $sql = "select   loan.amount_borrowed from loan where loan_id=:loan_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['amount_borrowed'];
        echo $field;
    } function get_chosen_loan_rate($id) {
        
        $db = new dbconnection();
        $sql = "select   loan.rate from loan where loan_id=:loan_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['rate'];
        echo $field;
    } function get_chosen_loan_amount_due($id) {
        
        $db = new dbconnection();
        $sql = "select   loan.amount_due from loan where loan_id=:loan_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['amount_due'];
        echo $field;
    } function get_chosen_loan_status($id) {
        
        $db = new dbconnection();
        $sql = "select   loan.status from loan where loan_id=:loan_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['status'];
        echo $field;
    } function get_chosen_loan_customer($id) {
        
        $db = new dbconnection();
        $sql = "select   loan.customer from loan where loan_id=:loan_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':loan_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['customer'];
        echo $field;
    }

 function All_loan() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  loan_id   from loan";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_loan() {
        $con = new dbconnection();
        $sql = "select loan.loan_id from loan
                    order by loan.loan_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['loan_id'];
        return $first_rec;
    }
 function get_last_loan() {
        $con = new dbconnection();
        $sql = "select loan.loan_id from loan
                    order by loan.loan_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['loan_id'];
        return $first_rec;
    }
function list_transaction($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from transaction";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> transaction </td>
<td> amount </td><td> date </td><td> balance </td><td> trans_type </td><td> bank_acc </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['transaction_id']; ?>
</td>
<td class="amount_id_cols transaction " title="transaction" >
<?php echo  $this->_e($row['amount']); ?>
</td>
<td>
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['balance']); ?>
</td>
<td>
<?php echo  $this->_e($row['trans_type']); ?>
</td>
<td>
<?php echo  $this->_e($row['bank_acc']); ?>
</td>


<td>
                        <a href="#" class="transaction_delete_link" style="color: #000080;" value="
                           <?php echo $row['transaction_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="transaction_update_link" style="color: #000080;" value="
                           <?php echo $row['transaction_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_transaction_amount($id) {
        
        $db = new dbconnection();
        $sql = "select   transaction.amount from transaction where transaction_id=:transaction_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':transaction_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['amount'];
        echo $field;
    } function get_chosen_transaction_date($id) {
        
        $db = new dbconnection();
        $sql = "select   transaction.date from transaction where transaction_id=:transaction_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':transaction_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_transaction_balance($id) {
        
        $db = new dbconnection();
        $sql = "select   transaction.balance from transaction where transaction_id=:transaction_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':transaction_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['balance'];
        echo $field;
    } function get_chosen_transaction_trans_type($id) {
        
        $db = new dbconnection();
        $sql = "select   transaction.trans_type from transaction where transaction_id=:transaction_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':transaction_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['trans_type'];
        echo $field;
    } function get_chosen_transaction_bank_acc($id) {
        
        $db = new dbconnection();
        $sql = "select   transaction.bank_acc from transaction where transaction_id=:transaction_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':transaction_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['bank_acc'];
        echo $field;
    }

 function All_transaction() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  transaction_id   from transaction";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_transaction() {
        $con = new dbconnection();
        $sql = "select transaction.transaction_id from transaction
                    order by transaction.transaction_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['transaction_id'];
        return $first_rec;
    }
 function get_last_transaction() {
        $con = new dbconnection();
        $sql = "select transaction.transaction_id from transaction
                    order by transaction.transaction_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['transaction_id'];
        return $first_rec;
    }
function list_customer($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from customer";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> customer </td>
<td> account </td><td> Natioanl_ID </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['customer_id']; ?>
</td>
<td class="account_id_cols customer " title="customer" >
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['Natioanl_ID']); ?>
</td>


<td>
                        <a href="#" class="customer_delete_link" style="color: #000080;" value="
                           <?php echo $row['customer_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="customer_update_link" style="color: #000080;" value="
                           <?php echo $row['customer_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_customer_account($id) {
        
        $db = new dbconnection();
        $sql = "select   customer.account from customer where customer_id=:customer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':customer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_customer_Natioanl_ID($id) {
        
        $db = new dbconnection();
        $sql = "select   customer.Natioanl_ID from customer where customer_id=:customer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':customer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['Natioanl_ID'];
        echo $field;
    }

 function All_customer() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  customer_id   from customer";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_customer() {
        $con = new dbconnection();
        $sql = "select customer.customer_id from customer
                    order by customer.customer_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['customer_id'];
        return $first_rec;
    }
 function get_last_customer() {
        $con = new dbconnection();
        $sql = "select customer.customer_id from customer
                    order by customer.customer_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['customer_id'];
        return $first_rec;
    }
 function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_customer_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select customer.customer_id,   customer.name from customer";
        ?>
        <select class="textbox cbo_customer"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['customer_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_loan_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select loan.loan_id,   loan.name from loan";
        ?>
        <select class="textbox cbo_loan"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['loan_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_customer_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select customer.customer_id,   customer.name from customer";
        ?>
        <select class="textbox cbo_customer"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['customer_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_trans_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select trans_type.trans_type_id,   trans_type.name from trans_type";
        ?>
        <select class="textbox cbo_trans_type"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['trans_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_bank_acc_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select bank_acc.bank_acc_id,   bank_acc.name from bank_acc";
        ?>
        <select class="textbox cbo_bank_acc"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['bank_acc_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }


 function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

