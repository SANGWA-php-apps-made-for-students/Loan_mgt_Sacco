
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`contact_us_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`date_contact`     Date 
,`message`     VARCHAR(60) 

,PRIMARY KEY (`contact_us_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`customer_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`Natioanl_ID`     VARCHAR(60) 

,PRIMARY KEY (`customer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
`transaction_id`     int(11) NOT NULL AUTO_INCREMENT 
, `amount`     int(11)   
,`date`     Date 
,`balance`     VARCHAR(60) 
, `trans_type`     int(11)   
, `bank_acc`     int(11)   

,PRIMARY KEY (`transaction_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
`loan_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `amount_borrowed`     int(11)   
, `rate`     int(11)   
, `amount_due`     int(11)   
,`status`     VARCHAR(60) 
, `customer`     int(11)   

,PRIMARY KEY (`loan_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `loan_payment`
--

CREATE TABLE IF NOT EXISTS `loan_payment` (
`loan_payment_id`     int(11) NOT NULL AUTO_INCREMENT 
, `loan`     int(11)   
,`date`     Date 
,`amount_paid`     Date 
, `remaining`     int(11)   

,PRIMARY KEY (`loan_payment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `bk_acc`
--

CREATE TABLE IF NOT EXISTS `bk_acc` (
`bk_acc_id`     int(11) NOT NULL AUTO_INCREMENT 
,`acc_number`     VARCHAR(60) 
,`date`     Date 
,`acc_type`     VARCHAR(60) 
, `customer`     int(11)   

,PRIMARY KEY (`bk_acc_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `trans_type`
--

CREATE TABLE IF NOT EXISTS `trans_type` (
`trans_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`trans_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

