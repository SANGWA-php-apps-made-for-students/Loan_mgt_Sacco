<?php 
class new_values{

 function new_account(  $account_category, $date_created, $profile, $username, $password, $is_online){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");$stm->execute(array(':account_id'=>0,':account_category'=>$account_category, ':date_created'=>$date_created, ':profile'=>$profile, ':username'=>$username, ':password'=>$password, ':is_online'=>$is_online
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account_category(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account_category values(:account_category_id, :name)");$stm->execute(array(':account_category_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");$stm->execute(array(':profile_id'=>0,':dob'=>$dob, ':name'=>$name, ':last_name'=>$last_name, ':gender'=>$gender, ':telephone_number'=>$telephone_number, ':email'=>$email, ':residence'=>$residence, ':image'=>$image
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_image(  $path){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into image values(:image_id, :path)");$stm->execute(array(':image_id'=>0,':path'=>$path
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_contact_us(  $account, $date_contact, $message){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into contact_us values(:contact_us_id, :account,  :date_contact,  :message)");$stm->execute(array(':contact_us_id'=>0,':account'=>$account, ':date_contact'=>$date_contact, ':message'=>$message
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_trans_type(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into trans_type values(:trans_type_id, :name)");$stm->execute(array(':trans_type_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_bk_acc(  $acc_number, $date, $acc_type, $customer){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into bk_acc values(:bk_acc_id, :acc_number,  :date,  :acc_type,  :customer)");$stm->execute(array(':bk_acc_id'=>0,':acc_number'=>$acc_number, ':date'=>$date, ':acc_type'=>$acc_type, ':customer'=>$customer
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_loan_payment(  $loan, $date, $amount_paid, $remaining){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into loan_payment values(:loan_payment_id, :loan,  :date,  :amount_paid,  :remaining)");$stm->execute(array(':loan_payment_id'=>0,':loan'=>$loan, ':date'=>$date, ':amount_paid'=>$amount_paid, ':remaining'=>$remaining
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_loan(  $date, $amount_borrowed, $rate, $amount_due, $status, $customer){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into loan values(:loan_id, :date,  :amount_borrowed,  :rate,  :amount_due,  :status,  :customer)");$stm->execute(array(':loan_id'=>0,':date'=>$date, ':amount_borrowed'=>$amount_borrowed, ':rate'=>$rate, ':amount_due'=>$amount_due, ':status'=>$status, ':customer'=>$customer
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_transaction(  $amount, $date, $balance, $trans_type, $bank_acc){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into transaction values(:transaction_id, :amount,  :date,  :balance,  :trans_type,  :bank_acc)");$stm->execute(array(':transaction_id'=>0,':amount'=>$amount, ':date'=>$date, ':balance'=>$balance, ':trans_type'=>$trans_type, ':bank_acc'=>$bank_acc
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_customer(  $account, $Natioanl_ID){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into customer values(:customer_id, :account,  :Natioanl_ID)");$stm->execute(array(':customer_id'=>0,':account'=>$account, ':Natioanl_ID'=>$Natioanl_ID
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
