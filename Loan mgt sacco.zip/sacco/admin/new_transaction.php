<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_transaction'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'transaction'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $transaction_id=$_SESSION['id_upd'];
                      
$amount = $_POST['txt_amount'];
$date = $_POST['txt_date'];
$balance = $_POST['txt_balance'];
$trans_type = $_POST['txt_trans_type_id'];

$bank_acc = $_POST['txt_bank_acc_id'];



$upd_obj->update_transaction($amount, $date, $balance, $trans_type, $bank_acc,$transaction_id);
unset($_SESSION['table_to_update']);
}}else{$amount = $_POST['txt_amount'];
$date = $_POST['txt_date'];
$balance = $_POST['txt_balance'];
$trans_type =trim( $_POST['txt_trans_type_id']);
$bank_acc =trim( $_POST['txt_bank_acc_id']);

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_transaction($amount, $date, $balance, $trans_type, $bank_acc);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
transaction</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_transaction.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_trans_type_id"   name="txt_trans_type_id"/><input type="hidden" id="txt_bank_acc_id"   name="txt_bank_acc_id"/>
      <?php
            include 'admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 transaction saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  transaction</div>
 <table class="new_data_table">


<tr><td>amount :</td><td> <input type="text"     name="txt_amount" required class="textbox" value="<?php echo trim(chosen_amount_upd());?>"   />  </td></tr>
<tr><td>date :</td><td> <input type="text"     name="txt_date" required class="textbox" value="<?php echo trim(chosen_date_upd());?>"   />  </td></tr>
<tr><td>balance :</td><td> <input type="text"     name="txt_balance" required class="textbox" value="<?php echo trim(chosen_balance_upd());?>"   />  </td></tr>
 <tr><td>trans_type :</td><td> <?php get_trans_type_combo(); ?>  </td></tr> <tr><td>bank_acc :</td><td> <?php get_bank_acc_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_transaction" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">transaction List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_transaction();
                    $obj->list_transaction($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_trans_type_combo() {
    $obj = new multi_values();
    $obj->get_trans_type_in_combo();
}
function get_bank_acc_combo() {
    $obj = new multi_values();
    $obj->get_bank_acc_in_combo();
}
function chosen_amount_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'transaction') {               $id = $_SESSION['id_upd'];
               $amount = new multi_values();
               return $amount->get_chosen_transaction_amount($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'transaction') {               $id = $_SESSION['id_upd'];
               $date = new multi_values();
               return $date->get_chosen_transaction_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_balance_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'transaction') {               $id = $_SESSION['id_upd'];
               $balance = new multi_values();
               return $balance->get_chosen_transaction_balance($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_trans_type_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'transaction') {               $id = $_SESSION['id_upd'];
               $trans_type = new multi_values();
               return $trans_type->get_chosen_transaction_trans_type($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_bank_acc_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'transaction') {               $id = $_SESSION['id_upd'];
               $bank_acc = new multi_values();
               return $bank_acc->get_chosen_transaction_bank_acc($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
