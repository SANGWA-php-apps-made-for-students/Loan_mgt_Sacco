<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_account'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'account'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $account_id=$_SESSION['id_upd'];
                      
$account_category =trim( $_POST['txt_account_category_id']);
$date_created = $_POST['txt_date_created'];
$profile = $_POST['txt_profile_id'];

$username = $_POST['txt_username'];
$password = $_POST['txt_password'];
$is_online = $_POST['txt_is_online'];


$upd_obj->update_account($account_category, $date_created, $profile, $username, $password, $is_online,$account_id);
unset($_SESSION['table_to_update']);
}}else{$account_category =trim( $_POST['txt_account_category_id']);
$date_created = $_POST['txt_date_created'];
$profile =trim( $_POST['txt_profile_id']);
$username = $_POST['txt_username'];
$password = $_POST['txt_password'];
$is_online = $_POST['txt_is_online'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_account($account_category, $date_created, $profile, $username, $password, $is_online);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
account</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_account_category_id"   name="txt_account_category_id"/><input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
      <?php
            include 'admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 account saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  account</div>
 <table class="new_data_table">


 <tr><td>account_category :</td><td> <?php get_account_category_combo(); ?>  </td></tr><tr><td>date_created :</td><td> <input type="text"     name="txt_date_created" required class="textbox" value="<?php echo trim(chosen_date_created_upd());?>"   />  </td></tr>
 <tr><td>profile :</td><td> <?php get_profile_combo(); ?>  </td></tr><tr><td>username :</td><td> <input type="text"     name="txt_username" required class="textbox" value="<?php echo trim(chosen_username_upd());?>"   />  </td></tr>
<tr><td>password :</td><td> <input type="text"     name="txt_password" required class="textbox" value="<?php echo trim(chosen_password_upd());?>"   />  </td></tr>
<tr><td>is_online :</td><td> <input type="text"     name="txt_is_online" required class="textbox" value="<?php echo trim(chosen_is_online_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_account" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">account List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_account();
                    $obj->list_account($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_account_category_combo() {
    $obj = new multi_values();
    $obj->get_account_category_in_combo();
}
function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}
function chosen_account_category_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'account') {               $id = $_SESSION['id_upd'];
               $account_category = new multi_values();
               return $account_category->get_chosen_account_account_category($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_date_created_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'account') {               $id = $_SESSION['id_upd'];
               $date_created = new multi_values();
               return $date_created->get_chosen_account_date_created($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'account') {               $id = $_SESSION['id_upd'];
               $profile = new multi_values();
               return $profile->get_chosen_account_profile($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_username_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'account') {               $id = $_SESSION['id_upd'];
               $username = new multi_values();
               return $username->get_chosen_account_username($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_password_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'account') {               $id = $_SESSION['id_upd'];
               $password = new multi_values();
               return $password->get_chosen_account_password($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_is_online_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'account') {               $id = $_SESSION['id_upd'];
               $is_online = new multi_values();
               return $is_online->get_chosen_account_is_online($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
