<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                sacco
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_profile.php">profile</a>
<a href="new_image.php">image</a>
<a href="new_contact_us.php">contact_us</a>
<a href="new_trans_type.php">trans_type</a>
<a href="new_bk_acc.php">bk_acc</a>
<a href="new_loan_payment.php">loan_payment</a>
<a href="new_loan.php">loan</a>
<a href="new_transaction.php">transaction</a>
<a href="new_customer.php">customer</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
