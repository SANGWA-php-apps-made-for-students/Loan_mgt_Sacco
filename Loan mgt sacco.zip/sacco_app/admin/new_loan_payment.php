<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_loan_payment'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan_payment') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $loan_payment_id = $_SESSION['id_upd'];

            $mul = new multi_values();
            $profile = $_POST['txt_profile_id'];
            $loan = $mul->get_loan_byCustomer($profile);
            $date = date('y-m-d');
            $amount_paid = $_POST['txt_amount_paid'];
            $remaining = 0;

            $upd_obj->update_loan_payment($loan, $date, $amount_paid, $remaining, $loan_payment_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $mul = new multi_values();
        $profile = $_POST['txt_profile_id'];
        $loan = trim($mul->get_loan_byCustomer($profile));
        $customer = $mul->get_customer_by_profile($profile);
        $date = date('y-m-d');
        $amount_paid = $_POST['txt_amount_paid'];

        ///------tot loan
        $tot_loan = $mul->get_tot_loan_by_customer($customer);
        $tot_loan_pay = $mul->get_tot_loan_paymnt_by_cutomer($customer);
        $debt_left = trim($tot_loan - ($tot_loan_pay + $amount_paid));
        if ($debt_left < 0) {
            ?><script>alert('The customer has finished paying the debt or is paying more than needed');</script><?php
        } else {
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_loan_payment($loan, $date, $amount_paid, $debt_left);
        }
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            loan_payment</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_loan_payment.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_loan_id"   name="txt_loan_id"/>
            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <?php
            include 'admin_header.php';
            $obj = new multi_values();
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                loan_payment saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered no_shade_noBorder big_t">  Loan Payment</div>
                <table class="new_data_table">

                    <tr><td>Customer :</td><td>   <?php chosen_profile_combo(); ?>  </td></tr>

                    <tr><td>amount_paid :</td><td> <input type="text"     name="txt_amount_paid" required class="textbox only_numbers" value="<?php echo trim(chosen_amount_paid_upd()); ?>"   />  </td></tr>
                    <tr class="off"><td>remaining :</td><td> <input type="text"     name="txt_remaining"  class="textbox" value="<?php echo trim(chosen_remaining_upd()); ?>"   />  </td></tr>


                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_loan_payment" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Loan payment List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_loan_payment();
                $obj->list_loan_payment($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function chosen_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function get_loan_combo() {
    $obj = new multi_values();
    $obj->get_loan_in_combo();
}

function chosen_loan_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan_payment') {
            $id = $_SESSION['id_upd'];
            $loan = new multi_values();
            return $loan->get_chosen_loan_payment_loan($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan_payment') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $date->get_chosen_loan_payment_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_amount_paid_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan_payment') {
            $id = $_SESSION['id_upd'];
            $amount_paid = new multi_values();
            return $amount_paid->get_chosen_loan_payment_amount_paid($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_remaining_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan_payment') {
            $id = $_SESSION['id_upd'];
            $remaining = new multi_values();
            return $remaining->get_chosen_loan_payment_remaining($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
