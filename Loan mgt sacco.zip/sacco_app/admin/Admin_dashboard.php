<?php
session_start();
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .fixed_box_xx{
                background-image: url('../web_images/sm_panebg.png');
                background-color: #fff;
            }
            .fixed_box_xx a{
                color: #fff;
            }
        </style>
    </head>
    <body>
        <?php
        require_once './admin_header.php';
        ?>
        <div class="eighty_centered">


            <?php
//Counting all records ...
            require_once '../web_db/multi_values.php';
            $count_obj = new multi_values();
            echo' <div class="parts fixed_box_xx ">account<br/>' . $count_obj->All_account() . '</div>                
                <div class="parts fixed_box_xx ">account_category<br/>' . $count_obj->All_account_category() . '</div>                
                <div class="parts fixed_box_xx ">profile<br/>' . $count_obj->All_profile() . '</div>                
                <div class="parts fixed_box_xx ">image<br/>' . $count_obj->All_image() . '</div>                
                <div class="parts fixed_box_xx ">contact_us<br/>' . $count_obj->All_contact_us() . '</div>                
                <div class="parts fixed_box_xx ">trans_type<br/>' . $count_obj->All_trans_type() . '</div>                
                <div class="parts fixed_box_xx ">bk_acc<br/>' . $count_obj->All_bk_acc() . '</div>                
                <div class="parts fixed_box_xx ">loan_payment<br/>' . $count_obj->All_loan_payment() . '</div>                
                <div class="parts fixed_box_xx ">loan<br/>' . $count_obj->All_loan() . '</div>                
                <div class="parts fixed_box_xx ">transaction<br/>' . $count_obj->All_transaction() . '</div>                
                <div class="parts fixed_box_xx ">customer<br/>' . $count_obj->All_customer() . '</div>                ';

//End conting all records .
            ?>


        </div>
    </body>

</html>
