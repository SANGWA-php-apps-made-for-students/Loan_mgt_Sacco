<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_contact_us'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $contact_us_id = $_SESSION['id_upd'];

            $account = trim($_POST['txt_account_id']);
            $date_contact = $_POST['txt_date_contact'];
            $message = $_POST['txt_message'];


            $upd_obj->update_contact_us($account, $date_contact, $message, $contact_us_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $account = trim($_POST['txt_account_id']);
        $date_contact = $_POST['txt_date_contact'];
        $message = $_POST['txt_message'];

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_contact_us($account, $date_contact, $message);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            contact_us</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_contact_us.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                contact_us saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered no_shade_noBorder big_t">  contact us</div>
                <table class="new_data_table">


                    <tr><td>account :</td><td> <?php get_account_combo(); ?>  </td></tr><tr><td>date_contact :</td><td> <input type="text"     name="txt_date_contact" required class="textbox" value="<?php echo trim(chosen_date_contact_upd()); ?>"   />  </td></tr>
                    <tr><td>message :</td><td> <input type="text"     name="txt_message" required class="textbox" value="<?php echo trim(chosen_message_upd()); ?>"   />  </td></tr>


                    <tr><td colspan="2">
                            <input type="submit" class="confirm_buttons" name="send_contact_us" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Contact us List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_contact_us();
                $obj->list_contact_us($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_contact_us_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_contact_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            $id = $_SESSION['id_upd'];
            $date_contact = new multi_values();
            return $date_contact->get_chosen_contact_us_date_contact($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_message_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            $id = $_SESSION['id_upd'];
            $message = new multi_values();
            return $message->get_chosen_contact_us_message($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
