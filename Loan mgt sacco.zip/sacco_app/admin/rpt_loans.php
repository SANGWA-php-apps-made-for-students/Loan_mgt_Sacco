<?php
session_start();
require_once '../web_db/multi_values.php';
?><!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Loans</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .dataList_table td{
                padding: 8px;
            }
        </style>
    </head>
    <body>
        <?php
        require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <div class="parts xx_titles no_paddin_shade_no_Border">
                Loans Report
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border search_bg">
                <table>
                    <tr>
                        <td>Enter acc number:</td>
                        <td><input type="text" class="textboxt txt_search_loans search_tbox only_numbers" /> </td>
                        <td><input type="button" value="Search"
                                   class="confirm_buttons margin_free btn_search_loan" /> </td>
                    </tr>
                </table>
            </div>
            <div class="parts res_box full_center_two_h ">

            </div>

        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>
