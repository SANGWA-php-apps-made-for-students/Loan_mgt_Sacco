<?php

session_start();

if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_image'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_customer'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_customer_id_by_customer_name($_POST['cbo_customer']);
    return $id;
}
if (isset($_POST['cbo_loan'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_loan_id_by_loan_name($_POST['cbo_loan']);
    return $id;
}
if (isset($_POST['cbo_customer'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_customer_id_by_customer_name($_POST['cbo_customer']);
    return $id;
}
if (isset($_POST['cbo_trans_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_trans_type_id_by_trans_type_name($_POST['cbo_trans_type']);
    return $id;
}
if (isset($_POST['cbo_bank_acc'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_bank_acc_id_by_bank_acc_name($_POST['cbo_bank_acc']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}

if (isset($_POST['table_to_update'])) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from account
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);
}
//The Delete from account_category
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account_category($id);
}
//The Delete from profile
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);
}
//The Delete from image
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_image($id);
}
//The Delete from contact_us
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'contact_us') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_contact_us($id);
}
//The Delete from trans_type
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'trans_type') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_trans_type($id);
}
//The Delete from bk_acc
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'bk_acc') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_bk_acc($id);
}
//The Delete from loan_payment
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'loan_payment') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_loan_payment($id);
}
//The Delete from loan
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'loan') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_loan($id);
}
//The Delete from transaction
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'transaction') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_transaction($id);
}
//The Delete from customer
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'customer') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_customer($id);
}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
if (isset($_POST['approve_loan'])) {
    require_once '../web_db/updates.php';
    $obj = new updates();
    $approve_loan = $_POST['approve_loan'];

    $obj->update_loan_status('approved', $approve_loan);
}
if (isset($_POST['acc_search'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $acc = $_POST['acc_search'];
    $balance = $obj->get_balance($acc);
}
if (isset($_POST['acc_search_loan'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $acc = $_POST['acc_search_loan'];
    $balance = $obj->get_loans($acc);
}
if (isset($_POST['acc_search_cust'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $NID = $_POST['acc_search_cust'];
    echo $balance = $obj->get_customer_details($NID);
}