<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_loan'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $loan_id = $_SESSION['id_upd'];

            $date = date('y-m-d');
            $amount_borrowed = $_POST['txt_amount_borrowed'];
            $rate = $_POST['txt_rate'];
            
            $reason = $_POST['reason'];
            $status = 'Pending';
            $customer = $_POST['txt_customer_id'];

            $upd_obj->update_loan($date, $amount_borrowed, $rate, $reason,$status, $customer, $loan_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $mul = new multi_values();
        $profile = $_POST['txt_profile_id'];
        $customer = $mul->get_customer_by_profile($profile);
        if (trim($mul->get_loan_by_customer($customer, 'pending')) == 0) {
            $date = date('y-m-d');
            $amount_borrowed = $_POST['txt_amount_borrowed'];
            $rate = $_POST['txt_rate'];
            $reason = $_POST['reason'];
            $status = 'Pending';
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_loan($date, $amount_borrowed, $rate, $reason, $status, $customer);
        } else {
            ?><script> alert('The customer has already another debt');</script><?php
        }
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            Loan</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_loan.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <input type="hidden" id="txt_customer_id"   name="txt_customer_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                loan saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered no_shade_noBorder big_t">  New Loan </div>
                <table class="new_data_table">
                    <tr><td>amount_borrowed :</td><td> <input type="text"     name="txt_amount_borrowed" required class="textbox only_numbers" value="<?php echo trim(chosen_amount_borrowed_upd()); ?>"   />  </td></tr>
                    <tr><td>rate :</td><td> <input type="text"     name="txt_rate" required class="textbox" value="<?php echo trim(chosen_rate_upd()); ?>"   />  </td></tr>
                     <tr><td>reason :</td><td> <input type="text"     name="reason" required class="textbox " value="<?php echo trim(chosen_amount_due_upd()); ?>"   />  </td></tr>

                    <tr><td>customer :</td><td> <?php chosen_profile_combo(); ?>  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_loan" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Loan List</div>
                <?php
                if ($_SESSION['cat'] == 'manager') {
                    $obj = new multi_values();
                    $first = $obj->get_first_loan();
                    $obj->list_loan_manger($first);
                } else {
                    $obj = new multi_values();
                    $first = $obj->get_first_loan();
                    $obj->list_loan($first);
                }
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function chosen_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function get_customer_combo() {
    $obj = new multi_values();
    $obj->get_customer_in_combo();
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $date->get_chosen_loan_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_amount_borrowed_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            $id = $_SESSION['id_upd'];
            $amount_borrowed = new multi_values();
            return $amount_borrowed->get_chosen_loan_amount_borrowed($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_rate_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            $id = $_SESSION['id_upd'];
            $rate = new multi_values();
            return $rate->get_chosen_loan_rate($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_amount_due_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            $id = $_SESSION['id_upd'];
            $amount_due = new multi_values();
            return $amount_due->get_chosen_loan_amount_due($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            $id = $_SESSION['id_upd'];
            $status = new multi_values();
            return $status->get_chosen_loan_status($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_customer_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'loan') {
            $id = $_SESSION['id_upd'];
            $customer = new multi_values();
            return $customer->get_chosen_loan_customer($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
