<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_profile'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $profile_id = $_SESSION['id_upd'];

            $dob = $_POST['txt_dob'];
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $gender = $_POST['txt_gender'];
            $telephone_number = $_POST['txt_telephone_number'];
            $email = $_POST['txt_email'];
            $residence = $_POST['txt_residence'];
            $image = $_POST['txt_image_id'];
            $upd_obj->update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $dob = $_POST['txt_dob'];
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $gender = $_POST['txt_gender'];
        $telephone_number = $_POST['txt_telephone_number'];
        $email = $_POST['txt_email'];
        $residence = $_POST['txt_residence'];
        $image = trim($_POST['txt_image_id']);

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            profile</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .dataList_table td{
                padding: 10px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <form action="new_profile.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_image_id"   name="txt_image_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <div class="parts eighty_centered no_paddin_shade_no_Border">  
            </div>
            <div class="parts eighty_centered off saved_dialog">
                profile saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered no_shade_noBorder big_t">  Profile Registration</div>
                <table class="new_data_table">
                    <tr><td>Date of Birth :</td><td> <input type="text"     name="txt_dob" required class="textbox" value="<?php echo trim(chosen_dob_upd()); ?>"   />  </td></tr>
                    <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                    <tr><td>last_name :</td><td> <input type="text"     name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                    <tr><td>gender :</td><td> <input type="text"     name="txt_gender" required class="textbox" value="<?php echo trim(chosen_gender_upd()); ?>"   />  </td></tr>
                    <tr><td>telephone_number :</td><td> <input type="text"     name="txt_telephone_number" required class="textbox" value="<?php echo trim(chosen_telephone_number_upd()); ?>"   />  </td></tr>
                    <tr><td>email :</td><td> <input type="text"     name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                    <tr><td>residence :</td><td> <input type="text"     name="txt_residence" required class="textbox" value="<?php echo trim(chosen_residence_upd()); ?>"   />  </td></tr>
                    <tr><td>image :</td><td> <?php get_image_combo(); ?>  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_profile" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Profile List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_profile();
                $obj->list_profile($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_image_combo() {
    $obj = new multi_values();
    $obj->get_image_in_combo();
}

function chosen_dob_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $dob = new multi_values();
            return $dob->get_chosen_profile_dob($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_profile_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_last_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $last_name = new multi_values();
            return $last_name->get_chosen_profile_last_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_gender_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $gender = new multi_values();
            return $gender->get_chosen_profile_gender($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_telephone_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $telephone_number = new multi_values();
            return $telephone_number->get_chosen_profile_telephone_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_email_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $email = new multi_values();
            return $email->get_chosen_profile_email($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_residence_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $residence = new multi_values();
            return $residence->get_chosen_profile_residence($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_image_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $image = new multi_values();
            return $image->get_chosen_profile_image($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
