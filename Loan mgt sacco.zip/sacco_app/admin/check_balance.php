<?php
session_start();
require_once '../web_db/multi_values.php';
?><html>
    <head>
        <title>Sacco</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include 'admin_header.php';
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <div class="parts full_center_two_h heit_free search_bg">
                <table>

                    <tr>
                        <td>Enter the Account number</td>
                        <td><input  type="text" placeholder="Account number" class="textbox search_tbox only_numbers" /></td>
                        <td><input  type="submit" style="margin: 0px;" value="Search" class="confirm_buttons btn_search_balance" /> </td>
                    </tr>

                </table>
            </div>
            <div class="parts full_center_two_h  res_box">

            </div>
            <?php
//            $obj = new multi_values();
//            $first = $obj->get_first_transaction();
//            $obj->get_balance();
            ?>
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>

