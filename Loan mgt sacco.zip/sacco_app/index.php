<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/>    </head>
    <body>
        <?php
        include 'header_menu.php';
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <span id="dd"></span>
            <div class="parts full_center_two_h margin_free accept_abs" id="bg_top">
                <div class="parts abs_full no_bg slider bigger_title off" id="slide_1">
                    Save your money
                </div>
                <div class="parts abs_full no_bg slider bigger_title off" id="slide_2">
                    for your Family
                </div>
            </div>
            <div class="parts full_center_two_h margin_free heit_free no_paddin_shade_no_Border reverse_border" style="margin-top: 20px;">
                <div class="parts thirty_Per_cent_two_h heit_free margin_free no_paddin_shade_no_Border reverse_border ">
                    <div class="parts full_center_two_h heit_free margin_free bigtitle pane_title_bg">
                        Find us
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border p_c">
                        <p style="color:blue; font-size:18px; ">-On Facebook Sacco Gatenga</p>
                        <p style="color:green; font-size:18px; ">-E-mail: gatengasacco.rw</p>
                        <p style="color:blue; font-size:18px; ">-Contact:+250784844965</p>
                    </div>
                </div>

                <div class="parts thirty_Per_cent_two_h heit_free " id="center_bg">

                </div>
                <div class="parts thirty_Per_cent_two_h heit_free no_paddin_shade_no_Border reverse_border" id="right_pane"> 
                    <div class="parts full_center_two_h heit_free margin_free bigtitle pane_title_bg">   Services
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border p_c">
                     <p style="color:blue; font-size:18px; ">-Creating Account Of Customers</p>
                        <p style="color:green; font-size:18px; ">-Withdraw/Deposit</p>
                        <p style="color:blue; font-size:18px; ">-We Offer Loans For Our Customers</p>
                    </div>
                </div>
            </div>

        </div>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        


        <div class="parts eighty_centered footer">
             <p style="color:blue; font-size:14px; ">GATENGA SACCO <?php echo date("y-m-d"); ?></p> 
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div>        </div>   
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>

    </body>
</html>
