-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2018 at 07:41 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id` int(11) NOT NULL,
  `account_category` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `account_category`, `date_created`, `profile`, `username`, `password`, `is_online`) VALUES
(22, 8, '2018-02-22', 14, 'muk@saaco.rw', 'MK1*', 'no'),
(25, 9, '2018-02-24', 17, 'paul@sacco.rw', 'P1*/', 'no'),
(28, 10, '2018-02-24', 20, 'samuel@sacco.rw', 'Sa*12', 'no'),
(29, 12, '2018-02-24', 21, 'silver@sacco.rw', 'Si1*', 'no'),
(30, 13, '2018-03-04', 24, 'daniella', '123', 'no'),
(31, 13, '2018-03-04', 25, 'tibomu', '123', 'no'),
(34, 11, '2018-03-14', 28, 'mukacha@sacco.rw', 'Mu1*', 'no'),
(35, 13, '2018-03-14', 29, 'titioti@sacco.rw', '123', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `account_category`
--

INSERT INTO `account_category` (`account_category_id`, `name`) VALUES
(8, 'admin'),
(9, 'customer_c'),
(10, 'cashier'),
(11, 'manager'),
(12, 'loan_manager'),
(13, 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `bk_acc`
--

CREATE TABLE IF NOT EXISTS `bk_acc` (
`bk_acc_id` int(11) NOT NULL,
  `acc_number` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `acc_type` varchar(60) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bk_acc`
--

INSERT INTO `bk_acc` (`bk_acc_id`, `acc_number`, `date`, `acc_type`, `customer`) VALUES
(1, '0400', '2018-03-04', 'Current', 1),
(2, '0401', '2018-03-04', 'fixed', 2),
(3, '0402', '2018-03-04', 'saving', 3),
(4, '0403', '2018-03-04', 'Current', 4),
(5, '0501', '2018-03-14', 'current', 5);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`contact_us_id` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `date_contact` date DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`customer_id` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `Natioanl_ID` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `account`, `Natioanl_ID`) VALUES
(1, 30, '1199354875235'),
(2, 31, '119784562135'),
(3, 32, '119785642236'),
(4, 33, '199854230147'),
(5, 35, '12009800452635');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id` int(11) NOT NULL,
  `path` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
`loan_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `amount_borrowed` int(11) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  `amount_due` int(11) DEFAULT NULL,
  `reason` varchar(50) NOT NULL,
  `status` varchar(60) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `date`, `amount_borrowed`, `rate`, `amount_due`, `reason`, `status`, `customer`) VALUES
(1, '2018-03-04', 55000, 5, 5222, '', 'approved', 1),
(2, '2018-03-04', 40000, 5, 2312, '', 'approved', 2),
(3, '2018-03-14', 2000000, 5, 0, 'kugura imodoka', 'Pending', 5);

-- --------------------------------------------------------

--
-- Table structure for table `loan_payment`
--

CREATE TABLE IF NOT EXISTS `loan_payment` (
`loan_payment_id` int(11) NOT NULL,
  `loan` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount_paid` int(11) DEFAULT NULL,
  `remaining` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loan_payment`
--

INSERT INTO `loan_payment` (`loan_payment_id`, `loan`, `date`, `amount_paid`, `remaining`) VALUES
(1, 1, '2018-03-09', 500, 0),
(2, 1, '2018-03-04', 20500000, 5000),
(3, 2, '2018-03-04', 15000, 25000),
(4, 2, '2018-03-04', 20000, 5000),
(5, 1, '2018-03-09', 50001, 0);

-- --------------------------------------------------------

--
-- Table structure for table `loan_requested`
--

CREATE TABLE IF NOT EXISTS `loan_requested` (
`loan_id` int(5) NOT NULL,
  `date` date NOT NULL,
  `amount_borrowed` int(25) NOT NULL,
  `rate` int(4) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `status` varchar(25) NOT NULL,
  `customer` int(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan_requested`
--

INSERT INTO `loan_requested` (`loan_id`, `date`, `amount_borrowed`, `rate`, `reason`, `status`, `customer`) VALUES
(1, '2018-03-06', 5834567, 4, 'kwishyura ideni', 'pending', 70);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `telephone_number` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  `image` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profile_id`, `dob`, `name`, `last_name`, `gender`, `telephone_number`, `email`, `residence`, `image`) VALUES
(14, '1990-01-01', 'MUSHIKIWINTWARI', 'Cynthian', 'Female', '07886564736', 'musema@gmail.com', 'NYARUGENGE', 1),
(15, '2018-02-14', 'Peter', 'HIRWA', 'Male', '07857555756', 'peter@gmail.com', 'Kimisagara', 1),
(16, '2018-02-12', 'Patrick', 'MUHirwa', 'Male', '07887646466', 'patrick@gmail.com', 'asdklj', 1),
(17, '2018-02-12', 'paul@gmai.com', 'MUWENIMANA', 'Male', '0788656435', 'paul@gmail.com', 'Rwamagana', 1),
(18, '2018-02-14', 'Patrick', 'HABIMANA', 'Male', '0788475757', 'patrick@gmail.com', 'kimironko', 1),
(19, '2018-02-15', 'Hugues', 'KAYIMBA', 'Male', '078857576', 'hugues@gmail.com', 'Nyamirambo', 1),
(20, '2018-02-13', 'Samuel', 'HABIMANA', 'Male', '0788376342', 'samuel@gmail.com', 'Nyamagabe', 1),
(21, '2018-02-05', 'Sivere', 'MURUNDAHABI', 'Male', '0788674646', 'silver@gmail.com', 'Nyamirambo', 1),
(22, '2018-02-13', 'manyinya', 'jean', 'Male', '0782345678', 'ma@gmail.com', 'kigakl', 1),
(23, '2018-02-06', 'fghuj', 'tgyhujik', 'Male', '5525555', 'jkkjkk', 'knmmk', 1),
(24, '2018-03-01', 'UMURERWA', 'Daniella', 'Female', '0784617888', 'umudani@gmail.com', 'kibungo', 1),
(25, '2018-03-03', 'MUGISHA', 'tibo', 'Male', '0784591232', 'mutibo@gmail.com', 'nyarugenge', 1),
(26, '2018-02-14', 'Nadine', 'batarenga arc digne', 'Female', '0789456123', 'banadigne', 'Musanze', 1),
(27, '2018-01-01', 'HORANA', 'Gaby chrispin', 'Male', '0712346975', 'hogachris@gmail.com', 'rubavu', 1),
(28, '1990-05-04', 'MUKANTWARI', 'Chantal', 'Female', '0784844965', 'mukacha@sacco.rw', 'kicukiro', 1),
(29, '2006-08-09', 'TITI', 'Tio', 'Male', '0784401245', 'titio@gmail.com', 'gasabo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
`transaction_id` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `balance` varchar(60) DEFAULT NULL,
  `trans_type` int(11) DEFAULT NULL,
  `bank_acc` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `amount`, `date`, `balance`, `trans_type`, `bank_acc`) VALUES
(1, 34400, '2018-03-13', '34400', 9, 3),
(2, 4500, '2018-03-13', '29900', 8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `trans_type`
--

CREATE TABLE IF NOT EXISTS `trans_type` (
`trans_type_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trans_type`
--

INSERT INTO `trans_type` (`trans_type_id`, `name`) VALUES
(8, 'withdraw'),
(9, 'deposit');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
 ADD PRIMARY KEY (`account_id`), ADD KEY `acc_profile_idx` (`profile`);

--
-- Indexes for table `account_category`
--
ALTER TABLE `account_category`
 ADD PRIMARY KEY (`account_category_id`);

--
-- Indexes for table `bk_acc`
--
ALTER TABLE `bk_acc`
 ADD PRIMARY KEY (`bk_acc_id`), ADD KEY `bankAcc_customer_idx` (`customer`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
 ADD PRIMARY KEY (`contact_us_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
 ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
 ADD PRIMARY KEY (`loan_id`), ADD KEY `loan_customer_idx` (`customer`);

--
-- Indexes for table `loan_payment`
--
ALTER TABLE `loan_payment`
 ADD PRIMARY KEY (`loan_payment_id`);

--
-- Indexes for table `loan_requested`
--
ALTER TABLE `loan_requested`
 ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
 ADD PRIMARY KEY (`profile_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
 ADD PRIMARY KEY (`transaction_id`), ADD KEY `trans_acc_idx` (`bank_acc`);

--
-- Indexes for table `trans_type`
--
ALTER TABLE `trans_type`
 ADD PRIMARY KEY (`trans_type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `account_category`
--
ALTER TABLE `account_category`
MODIFY `account_category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `bk_acc`
--
ALTER TABLE `bk_acc`
MODIFY `bk_acc_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
MODIFY `contact_us_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `loan_payment`
--
ALTER TABLE `loan_payment`
MODIFY `loan_payment_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `loan_requested`
--
ALTER TABLE `loan_requested`
MODIFY `loan_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `trans_type`
--
ALTER TABLE `trans_type`
MODIFY `trans_type_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
ADD CONSTRAINT `acc_profile` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `bk_acc`
--
ALTER TABLE `bk_acc`
ADD CONSTRAINT `bankAcc_customer` FOREIGN KEY (`customer`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `loan`
--
ALTER TABLE `loan`
ADD CONSTRAINT `loan_customer` FOREIGN KEY (`customer`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
ADD CONSTRAINT `trans_acc` FOREIGN KEY (`bank_acc`) REFERENCES `bk_acc` (`bk_acc_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
