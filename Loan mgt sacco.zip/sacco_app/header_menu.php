<div class="parts  eighty_centered " id="header_bg">   
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        GATENGA Sacco
    </div>
</div>    
<div class="parts menu eighty_centered no_shade_noBorder off">
    <a href="index.php">Home</a>
    <a href="#">About us</a>
    <a href="#">Contact us</a>
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
