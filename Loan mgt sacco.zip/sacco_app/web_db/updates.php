<?php

require_once 'connection.php';

class updates {

    function update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
        $stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $account_id));
    }

    function update_account_username($n_password, $username) {
        try {
            $database = new dbconnection();
            $db = $database->openconnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE account set  password= ?  WHERE username=?");
            $stmt->execute(array($n_password, $username));
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function update_account_category($name, $account_category_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
        $stmt->execute(array($name, $account_category_id));
    }

    function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
        $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
    }

    function update_image($path, $image_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
        $stmt->execute(array($path, $image_id));
    }

    function update_contact_us($account, $date_contact, $message, $contact_us_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE contact_us set 
account= ?, date_contact= ?, message= ? WHERE contact_us_id=?");
        $stmt->execute(array($account, $date_contact, $message, $contact_us_id));
    }

    function update_trans_type($name, $trans_type_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE trans_type set 
name= ? WHERE trans_type_id=?");
        $stmt->execute(array($name, $trans_type_id));
    }

    function update_bk_acc($acc_number, $date, $acc_type, $customer, $bk_acc_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE bk_acc set 
acc_number= ?, date= ?, acc_type= ?, customer= ? WHERE bk_acc_id=?");
        $stmt->execute(array($acc_number, $date, $acc_type, $customer, $bk_acc_id));
    }

    function update_loan_payment($loan, $date, $amount_paid, $remaining, $loan_payment_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE loan_payment set 
loan= ?, date= ?, amount_paid= ?, remaining= ? WHERE loan_payment_id=?");
        $stmt->execute(array($loan, $date, $amount_paid, $remaining, $loan_payment_id));
    }

    function update_loan($date, $amount_borrowed, $rate, $amount_due, $status, $customer, $loan_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE loan set 
date= ?, amount_borrowed= ?, rate= ?, amount_due= ?, status= ?, customer= ? WHERE loan_id=?");
        $stmt->execute(array($date, $amount_borrowed, $rate, $amount_due, $status, $customer, $loan_id));
    }

    function update_loan_status($status, $loan_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE loan set status= ?  WHERE loan_id=?");
        $stmt->execute(array($status, $loan_id));
        echo 'update done';
    }

    function update_transaction($amount, $date, $balance, $trans_type, $bank_acc, $transaction_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE transaction set 
amount= ?, date= ?, balance= ?, trans_type= ?, bank_acc= ? WHERE transaction_id=?");
        $stmt->execute(array($amount, $date, $balance, $trans_type, $bank_acc, $transaction_id));
    }

    function update_customer($account, $Natioanl_ID, $customer_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE customer set 
account= ?, Natioanl_ID= ? WHERE customer_id=?");
        $stmt->execute(array($account, $Natioanl_ID, $customer_id));
    }

}
