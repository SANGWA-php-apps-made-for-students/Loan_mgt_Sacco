<?php
if ($_SESSION['cat'] == 'admin') {
    manager_menu();
} else if ($_SESSION['cat'] == 'customer_care') {
    customer_c_menu();
} else if ($_SESSION['cat'] == 'cashier') {
    cashier_menu();
} else if ($_SESSION['cat'] == 'loan_manager') {
    loan_manager();
} else if ($_SESSION['cat'] == 'manager') {//this will be the f
    admin_menu();
}

// <editor-fold defaultstate="collapsed" desc="--- these are the menus fnxz ------">

function admin_menu() {
    ?>
    <div class="parts  eighty_centered " id="header_bg"> 
        <div class="parts  no_paddin_shade_no_Border xxx_titles">
            <?php echo 'Sacco  - ' . welcome_user() ?>
        </div>
    </div>  
    <div class="parts menu eighty_centered menu_bg">
        <div class="parts off"> <a href="new_account.php">Account</a>
            <a href="new_account_category.php">Account_category</a>
            <a href="new_profile.php">Profile</a>
            <a href="new_image.php">Image</a>
            <a href="new_contact_us.php">Contact us</a>
        </div>
    </div>     
    <?php
}

function cashier_menu() {
    ?>
    <div class="parts  eighty_centered " id="header_bg"> 
        <div class="parts  no_paddin_shade_no_Border xxx_titles">
            <?php echo 'Sacco' . ' - ' . welcome_user() ?>
        </div>
    </div>  
    <div class="parts menu eighty_centered menu_bg">
        <a href="new_transaction.php">Withdraw/Deposit</a>
        <a href="#">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Customer
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="new_customer.php" style="margin: 0px;color: green"> customer account</a></td>

                            </tr>

                        </table>
                    </div>
                </div>
            </div>
        </a>
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Loan 
                <div class="parts hovable_item">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="rpt_loans.php" style="margin: 0px; color: green ">Loan balance</a></td>

                            </tr>
                            <tr>

                                <td><a href="new_loan_payment.php" style="margin: 0px;color: blue">Loan payment</a></td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>

        <a href="check_balance.php" >Balance</a>
        <a href="../logout.php">Logout</a>
        <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">

        </div>
    </div>
    <?php
}

function loan_manager() {
    ?>
    <div class="parts  eighty_centered " id="header_bg"> 
        <div class="parts  no_paddin_shade_no_Border xxx_titles">
            <?php echo 'Sacco  - ' . welcome_user() ?>
        </div>
    </div>  
    <div class="parts menu eighty_centered menu_bg">
        <a href="#">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Customer
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                            </tr>
                            <tr>
                                <td><a href="new_customer.php" style="margin: 0px; color: green">Customer details</a></td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Loan
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="new_loan.php" style="margin: 0px; color: green">New loan</a></td>

                            </tr>
                            <tr>

                                <td><a href="new_loan_payment.php" style="margin: 0px;color: blue">Loan payment</a></td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Balance
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="rpt_loans.php" style="margin: 0px;color: green">Loan balance </a></td>

                            </tr>
                            <tr>

                                <td><a href="check_balance.php" style="margin: 0px; color: blue">Account balance</a></td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>
        <a href="../logout.php">Logout</a>
    </div> 
    <?php
}

function manager_menu() {
    ?>
    <div class="parts  eighty_centered " id="header_bg"> 
        <div class="parts  no_paddin_shade_no_Border xxx_titles">
            <?php echo 'Sacco  - ' . welcome_user() ?>
        </div>
    </div>  
    <div class="parts menu eighty_centered menu_bg">
        <div class="parts off">
            <a href="new_account.php">Account</a>
            <a href="new_account_category.php">Account_category</a>
            <a href="new_profile.php">Profile</a>
            <a href="new_image.php">Image</a>
            <a href="new_contact_us.php">Contact us</a>
        </div>
        <a href="#">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Customer
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="new_customer.php" style="margin: 0px; color: green">customer account</a></td>

                            </tr>
                            <tr>

                                <td><a href="new_customer.php" style="margin: 0px; color: blue">Customer details</a></td>

                            </tr>
                            <tr>

                                <td><a href="check_balance.php" style="margin: 0px; color: green"> balance</a></td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Staff
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="new_account.php" style="margin: 0px; color: green">New staff</a></td>
                            </tr>
                            <tr>
                                <td><a href="change_pass.php" style="margin: 0px; color: #000;color: blue">Staff change</a></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>       
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Loan
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>

                                <td><a href="Requested_loan.php" style="margin: 0px; color: green"> Requested loans</a></td>

                            </tr>
                            <tr>
                                <td><a  href="new_loan.php" style="margin: 0px; color: blue">Approval loans</a></td>

                            </tr>
                            <tr>

                                <td><a href="rpt_loans.php" style="margin: 0px; color: green"> Loan balance</a></td>

                            </tr>

                            <tr>

                                <td><a href="new_trans_type.php" style="margin: 0px;  color: blue"> Report</a></td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </a>       
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Transactions

            </div>
        </a>       
        <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
            <a href="../logout.php">Logout</a>
        </div>
    </div>
    <?php
}

function customer_c_menu() {
    ?>
    <div class="parts  eighty_centered " id="header_bg"> 
        <div class="parts  no_paddin_shade_no_Border xxx_titles">
            <?php echo 'Sacco  - ' . welcome_user() ?>
        </div>
    </div>  
    <div class="parts menu eighty_centered menu_bg">
        <a href="#" style="margin: 0px;">
            <div class="parts left_off_x no_paddin_shade_no_Border margin_free allow_drop">
                Customer
                <div class="parts hovable_item ">
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <table class="menu_tab">
                            <tr>
                                <td><a  href="new_customer.php" style="margin: 0px; color: green">New customer</a></td>
                            </tr>

                        </table>
                    </div>
                </div>
            </div>
        </a>       
        <a href="new_bk_acc.php">Account</a>
        <a href="check_balance.php"> Balance</a>
        <a href="rpt_customers.php">Reports</a>
        <a href="../logout.php">Logout</a>

    </div>  
    <?php
}

function welcome_user() {
    return 'Welcome dear ' . $_SESSION['cat'] . ' --  ' . $_SESSION['names'];
}

// </editor-fold>